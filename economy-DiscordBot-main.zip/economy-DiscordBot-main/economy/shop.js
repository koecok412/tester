module.exports = {
  
  name: "shop",
  code: `$author[Shop.;$userAvatar[797794333759766528]] 
$description[**> Necessity:**

Pizza🍕
**$getServerVar[prefix]buy-pizza** = $95
**$getServerVar[prefix]eat-pizza** = If you are hungry, eat it. +2 Health, -6 Hungry, -4 Thirsty.

Drink🥛
**$getServerVar[prefix]buy-drink** = $45
**$getServerVar[prefix]drink** = If you are thirsty, drink it. +3 Health, -2 Hungry, -5 Thirsty.

Medicine💊
**$getServerVar[prefix]buy-medic** = $125
**$getServerVar[prefix]take-medicine** = When you are sick, wear it. +9 Health, -4 Hungry, -4 Thirsty.

**> Item :**

Fishing equipment🎣
**$getServerVar[prefix]buy-fishrod** = $75

Laptop🖱
**$getServerVar[prefix]buy-laptop** = $13.000

Car🚗
**$getServerVar[prefix]buy-car** = $65.000

Fuel⛽
**$getServerVar[prefix]buy-fuel** = $2500/1L

House🏡
**$getServerVar[prefix]buy-house** = $2.000.000
]
$color[RANDOM]
$footer[SOURCE CODE FROM Jastin Ch in Youtube || https://youtube.com/c/JastinCh || Full Made By JastinCh!]
$addTimestamp`
}