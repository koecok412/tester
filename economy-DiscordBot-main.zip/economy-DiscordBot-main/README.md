# economy-DiscordBot
Economic themed Discord Bot with quite a lot of commands and complete and a system of hunger, thirst, health like the real world.

# SETUP
- Type ```npm i``` in terminal.
- Fill all about your bot info in ```.env``` You can see ```.env-example``` as an example of populating ```.env```
- Run your bot with `node .` in your terminal and Enjoy!

*Video Tutorial: https://youtu.be/-x7S6_G_S3w*

# More

[![Awesome Badges](https://img.shields.io/badge/Subscribe%20In-Youtube-red)](https://youtube.com/c/JastinCh)
[![Library DBD.js](https://img.shields.io/badge/Library-DBD.js-blue)](https://dbd.leref.ga)

# ><
star the repo pls
